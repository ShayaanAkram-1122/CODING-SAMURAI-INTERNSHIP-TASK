const todoList = [];

renderTodoList();

function renderTodoList() {
  let todolistHtml = '';

  todoList.forEach(function(todo, index) {
    const html = `
      <div class="todo-row">
        <div class="todo-task">${todo.task}</div>
        <div class="todo-timestamp">${todo.timestamp}</div>
        <div class="todo-delete">
          <button class="delete-btn" onclick="
            todoList.splice(${index}, 1);
            renderTodoList();
          ">Delete</button>
        </div>
      </div>
    `;
    todolistHtml += html;
  });

  document.querySelector('.js-todo-list').innerHTML = todolistHtml;
}

function addtodo() {
  const inputElement = document.querySelector('.js-name-input');
  const name = inputElement.value.trim();

  if (name !== '') {
    const now = new Date();
    const timestamp = now.toLocaleString();
    todoList.push({ task: name, timestamp: timestamp });
  }

  inputElement.value = '';
  renderTodoList();
}
